-- LOWKEY Supabase setup
-- GANTI alamat email di bawah dengan email admin yang kamu pakai untuk login.
-- Jalankan seluruh SQL ini di Supabase > SQL Editor > New query.

create table if not exists public.roster (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  uid text not null unique,
  role text not null,
  photo_url text,
  created_at timestamptz not null default now()
);

alter table public.roster enable row level security;

drop policy if exists "Roster can be viewed by everyone" on public.roster;
create policy "Roster can be viewed by everyone"
on public.roster for select
to anon, authenticated
using (true);

drop policy if exists "Only LOWKEY admin can add roster" on public.roster;
create policy "Only LOWKEY admin can add roster"
on public.roster for insert
to authenticated
with check ((auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL');

drop policy if exists "Only LOWKEY admin can edit roster" on public.roster;
create policy "Only LOWKEY admin can edit roster"
on public.roster for update
to authenticated
using ((auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL')
with check ((auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL');

drop policy if exists "Only LOWKEY admin can delete roster" on public.roster;
create policy "Only LOWKEY admin can delete roster"
on public.roster for delete
to authenticated
using ((auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL');

-- Public image bucket: everyone can view photos, only the admin email can upload/delete.
insert into storage.buckets (id, name, public)
values ('roster-photos', 'roster-photos', true)
on conflict (id) do update set public = true;

drop policy if exists "Roster photos are public" on storage.objects;
create policy "Roster photos are public"
on storage.objects for select
to public
using (bucket_id = 'roster-photos');

drop policy if exists "LOWKEY admin can upload roster photos" on storage.objects;
create policy "LOWKEY admin can upload roster photos"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'roster-photos'
  and (auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL'
);

drop policy if exists "LOWKEY admin can update roster photos" on storage.objects;
create policy "LOWKEY admin can update roster photos"
on storage.objects for update
to authenticated
using (
  bucket_id = 'roster-photos'
  and (auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL'
)
with check (
  bucket_id = 'roster-photos'
  and (auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL'
);

drop policy if exists "LOWKEY admin can delete roster photos" on storage.objects;
create policy "LOWKEY admin can delete roster photos"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'roster-photos'
  and (auth.jwt() ->> 'email') = 'YOUR_ADMIN_EMAIL'
);
