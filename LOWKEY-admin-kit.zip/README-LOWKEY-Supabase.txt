# LOWKEY Admin + Supabase

File yang disiapkan:
- `LOWKEY-connected.html` — halaman utama yang bisa membaca roster online.
- `admin.html` — panel login dan kelola anggota.
- `supabase-setup.sql` — tabel, aturan akses, dan bucket foto.

## Langkah setup

1. Buat project di https://supabase.com/ dan simpan Project URL serta anon/public key.
2. Di Supabase > Authentication > Users, buat akun admin dengan email dan password milikmu.
   Matikan public signups di Authentication > Settings agar orang lain tidak bisa membuat akun sendiri.
3. Buka SQL Editor, tempel isi `supabase-setup.sql`. Sebelum menjalankan, ganti setiap `YOUR_ADMIN_EMAIL` dengan email akun admin yang dibuat pada langkah 2.
4. Di `LOWKEY-connected.html` dan `admin.html`, ganti:
   - `PASTE_SUPABASE_PROJECT_URL` dengan Project URL.
   - `PASTE_SUPABASE_ANON_KEY` dengan anon/public key (bukan service_role key).
5. Upload `LOWKEY-connected.html` ke GitHub sebagai `LOWKEY.html` untuk menggantikan halaman utama yang lama.
6. Upload `admin.html` ke folder yang sama. Alamat panelnya menjadi `https://noptaxx.github.io/LOWKEY/admin.html`.
7. Buka halaman admin, login, lalu tekan `IMPOR ROSTER AWAL`. Empat anggota lama akan dimasukkan. Foto bawaan di halaman utama tetap dipakai sampai foto anggota diganti dari panel admin.

## Keamanan
- Jangan pernah memasukkan `service_role` key ke HTML atau membagikannya.
- Anon/public key memang digunakan di browser; keamanan tulis/edit/hapus dijaga oleh Row Level Security dan email admin di SQL.
- Jangan bagikan password admin.
- Setelah setup, tes halaman utama dalam mode privat/incognito untuk memastikan roster publik terbaca.
